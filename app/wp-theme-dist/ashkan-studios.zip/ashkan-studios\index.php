<?php if (!defined('ABSPATH')) { exit; } status_header(200); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Ashkan Studios - Full-service production company specializing in commercial photography, videography, and creative direction. Based in Houston, TX." />
    <meta name="keywords" content="photography, videography, production, commercial, Houston, Ashkan Studios, Ashkan Image, Ashkan Media" />
    <meta name="author" content="Ashkan Studios" />
    <meta property="og:title" content="Ashkan Studios | Full-Service Production Company" />
    <meta property="og:description" content="We craft unforgettable visuals through commercial photography, videography, and creative direction." />
    <meta property="og:type" content="website" />
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E📷%3C/text%3E%3C/svg%3E" />
    <title>Ashkan Studios | Full-Service Production Company</title>
    <script type="module" crossorigin src="/assets/index-CEUulXCT.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-BmwitKmf.css">
      <?php wp_head(); ?>
  </head>
  <body>
    <div id="root"></div>
      <?php wp_footer(); ?>
  </body>
</html>
